#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <fstream>

using namespace std;

vector<vector<int>> loadGraph(string filename) {
	ifstream file(filename);
    string line, vertices, edges, u, v;

    getline(file, vertices, ' ');
	vector<vector<int>> adjacencyList(stoi(vertices));

	getline(file, edges, '\n');

    for (int i = 0; i < stoi(edges); i++) {
        getline(file, u, ' ');
		getline(file, v, '\n');
        adjacencyList[stoi(u)].push_back(stoi(v));
		adjacencyList[stoi(v)].push_back(stoi(u));
    }

	return adjacencyList;
}

int BFS(vector<vector<int>>& adjacencyList, int start, int limitDistance) {
	queue<int> q;
	vector<int> distance(adjacencyList.size(), -1);
	int totalInfected = 1;

	q.push(start);
	distance[start] = 0;

	int current;
	int descendant;
	while (!q.empty()) {
		current = q.front();
		q.pop();

		if (distance[current] == limitDistance) {
			break;
		}
		
		for (int i = 0; i < adjacencyList[current].size(); i++) {
			descendant = adjacencyList[current][i];
			if (distance[descendant] == -1) {
				q.push(descendant);
				distance[descendant] = distance[current] + 1;
				totalInfected++;
			}
		}
	}
	
	return totalInfected;
}

void findMaxVirus(vector<vector<int>> &adjacencyList, int time) {
	int totalInfected = 0, source;
	vector<int> sources;
	cout << "Vertice  Infectados" << endl;
	for (int i = 0; i < adjacencyList.size(); i++) {
		int currentInfected = BFS(adjacencyList, i, time);
		cout << i << "            " << currentInfected << endl;
		if (currentInfected >= totalInfected) {
			totalInfected = currentInfected;
			sources.push_back(i);
		}
	}

	cout << "\nMayor propagacion:" << endl;
	for (int i = 0; i < sources.size(); i++) {
		cout << "Vertice: " << sources[i] << " Infectados: " << totalInfected << endl;
	}	
	
}

int main() {
	int time;

	cout << "Grafo 1: " << endl;
	vector<vector<int>> graph1 = loadGraph("grafo1Evidencia.txt");
	cout << "Introduza el tiempo de infeccion: ";
	cin >> time;
	findMaxVirus(graph1, time);

	cout << "\nGrafo 2: " << endl;
	vector<vector<int>> graph2 = loadGraph("grafo2Evidencia.txt");
	cout << "Introduza el tiempo de infeccion: ";
	cin >> time;
	findMaxVirus(graph2, time);

	cout << "\nGrafo 3: " << endl;
	vector<vector<int>> graph3 = loadGraph("grafo3Evidencia.txt");
	cout << "Introduza el tiempo de infeccion: ";
	cin >> time;
	findMaxVirus(graph3, time);

	return 0;
}